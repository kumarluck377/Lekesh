package com.example.lekesh;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.GET;

interface Interface {
    @GET("repositories")
    Call<List<Item>> getCarsJson();
}


