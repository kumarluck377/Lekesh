package com.example.lekesh;

import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class ABC extends RecyclerView.Adapter<ABC.ViewHolder> {

    private ArrayList<Item> item =new ArrayList<>();
    private Context context;


    public ABC(Context context, ArrayList<Item> item) {
        this.item = item;
        this.context=context;
    }

    @NonNull
    @Override
    public ABC.ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.activity_2,viewGroup,false);
        return new ABC.ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ABC.ViewHolder viewHolder, int i) {
        viewHolder.car_name.setText(this.item.get(i).getName());


        final Item item = this.item.get(i);
        viewHolder.car_name.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(context, Detail.class);
                Log.d("modal", "test"+ item.getLogin());
                intent.putExtra("carName", item.getName());
                intent.putExtra("carLogin", item.getLogin());
                intent.putExtra("carFullName", item.getFull_name());



                context.startActivity(intent);
            }
        });

    }

    @Override
    public int getItemCount() {
        return item.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        //private ImageView car_image;
        private TextView car_name,car_desc;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            car_name=(TextView) itemView.findViewById(R.id.car_name);
            car_desc=(TextView)itemView.findViewById(R.id.car_desc);
        }
    }
}

