package com.example.lekesh;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class Detail extends AppCompatActivity {
    TextView name;
    TextView login;
    TextView fullname;
    TextView owner;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_1);
        name=findViewById(R.id.name);
        login=findViewById(R.id.login);
        fullname=findViewById(R.id.fullname);
        owner=findViewById(R.id.owner);



        Intent intent=getIntent();
        final String carName = intent.getStringExtra("carName");
        final String carLogin = intent.getStringExtra("carLogin");
        final String carFullName = intent.getStringExtra("carFullName");
        final String carOwner = intent.getStringExtra("carOwner");


        name.setText(carName);
        login.setText(carLogin);
        fullname.setText(carFullName);
    }
}